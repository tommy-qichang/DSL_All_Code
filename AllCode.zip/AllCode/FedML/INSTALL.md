## Installation

Please follow CI-install.sh for step-by-step installation.


