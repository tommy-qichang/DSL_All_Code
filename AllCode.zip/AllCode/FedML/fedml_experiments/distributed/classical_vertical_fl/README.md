## Installation
http://doc.fedml.ai/#/installation-distributed-computing

## Running Experiments 
```
sh run_vfl_distributed_pytorch.sh lending_club_loan
```