## Installation
http://doc.fedml.ai/#/installation-distributed-computing

## Running Experiments 

```
sh run_decentralized_demo_distributed_pytorch.sh
```