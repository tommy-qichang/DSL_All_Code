### Co-Authors:

*Chaoyang He (USC), Songze Li (Stanford), Jinhyun So (USC), Mi Zhang (USC), Hongyi Wang (Wisconsin Madison), Xiaoyang Wang (UIUC), Praneeth Vepakomma (MIT), Abhishek Singh (MIT), Hang Qiu (USC), Li Shen (Tencent), Peilin Zhao (Tencent), Yan Kang (WeBank), Yang Liu (WeBank), Ramesh Raskar (MIT), Qiang Yang (WeBank, HKUST), Murali Annavaram (USC), Salman Avestimehr (USC)*

Correponding Authors: Chaoyang He, Salman Avestimehr

### Project Leader:

Chaoyang He, PhD student, former Staff Software Engineer at Tencent

### Active Source Code Contributors:
Chaoyang He, PhD student, USC, USA

Hongyi Wang, PhD student, Wisconsin Madison, USA

Abhishek Singh, PhD student, MIT, USA

Praneeth Vepakomma, MIT, USA

Yan Kang, Principal Software Engineer, WeBank

Zongchang Jie, Principal Software Engineer, Tencent

Weizhou Pan, Team Manager, Senior Software Engineer, Tencent

Yufen Huang, MS, USC, USA

Jinhyun So, PhD student, USC, USA

Bill Yuchen Lin, PhD student, USC, USA

Yanfang Li, MS, USC, USA; Project Manager

Rodrigo Pecchio, BA in CS, USC, USA; will join AWS after graduation.

Ákos Gángoly, MSc in CS, BME, Hungary

Zihang Zeng, MS, USC, USA

Hulin Wang, MS, USC, USA

Jin-woo Lee, Research Professor, KAIST, South Korea

Zhenheng Tang, PhD student, HKBU, Hong Kong, China
