### Introduction
We reuse the dataset preprocessing published by FedProx (https://arxiv.org/abs/1812.06127).

```
python generate_synthetic.py
```

DATASET: synthetic_1_1
60 users
10684 samples (total)
178.07 samples per user (mean)
num_samples (std): 761.52
num_samples (std/mean): 4.28
num_samples (skewness): 7.27

num_sam num_users
0        25
20       1
40       11
60       8
80       1
100      2
120      1
140      4
160      1
180      0

