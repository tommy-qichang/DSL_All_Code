NAME="MNIST"
SUBDIR=$1

python3 stats.py --name $NAME --subdir $SUBDIR