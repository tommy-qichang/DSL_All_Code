Please manually download data into this directory. \
Download link: https://lms.comp.nus.edu.sg/wp-content/uploads/2019/research/nuswide/NUS-WIDE.html \
After downloading, the structure in this directory should be:

-ConceptsList

-Groundtruth

-ImageList

-Low_Level_Features

-NUS_WID_Tags

-NUS-WIDE-urls.txt

Once this is correct, please run "fedml_api/data_preprocessing/NUS_WIDE/nus_wide_dataset.py" to prepare the dataset.