Please manually download "loan.csv" file into this directory.
Download link: https://www.kaggle.com/wendykan/lending-club-loan-data