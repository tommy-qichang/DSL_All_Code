### Introduction
We reuse the dataset preprocessing published by FedProx (https://arxiv.org/abs/1812.06127).

```
python generate_synthetic.py
```

DATASET: synthetic_0.5_0.5
60 users
8977 samples (total)
149.62 samples per user (mean)
num_samples (std): 536.89
num_samples (std/mean): 3.59
num_samples (skewness): 7.08

num_sam num_users
0        22
20       5
40       9
60       4
80       6
100      1
120      2
140      0
160      4
180      1